import { users, compressionLogs, type User, type InsertUser, type CompressionLog, type InsertCompressionLog } from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, gte } from "drizzle-orm";
import { getLocalISOString } from "../shared/utils";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Compression logs
  createCompressionLog(log: InsertCompressionLog): Promise<CompressionLog>;
  getCompressionLogs(limit?: number): Promise<CompressionLog[]>;
  getCompressionLogsByUserId(userId?: number, limit?: number): Promise<CompressionLog[]>;
  getCompressionStats(): Promise<{
    totalCompressions: number;
    totalSizeSaved: number;
    averageCompressionRatio: number;
    averageSizeReduced: number;
  }>;
  getDailyCompressionStats(days: number): Promise<{
    date: string;
    count: number;
  }[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createCompressionLog(insertLog: InsertCompressionLog): Promise<CompressionLog> {
    const [log] = await db
      .insert(compressionLogs)
      .values(insertLog)
      .returning();
    return log;
  }

  async getCompressionLogs(limit = 10): Promise<CompressionLog[]> {
    return await db
      .select()
      .from(compressionLogs)
      .orderBy(desc(compressionLogs.createdAt))
      .limit(limit);
  }

  async getCompressionLogsByUserId(userId?: number, limit = 10): Promise<CompressionLog[]> {
    if (userId) {
      return await db
        .select()
        .from(compressionLogs)
        .where(eq(compressionLogs.userId, userId))
        .orderBy(desc(compressionLogs.createdAt))
        .limit(limit);
    } else {
      return await this.getCompressionLogs(limit);
    }
  }

  async getCompressionStats(): Promise<{
    totalCompressions: number;
    totalSizeSaved: number;
    averageCompressionRatio: number;
    averageSizeReduced: number;
  }> {
    const [result] = await db
      .select({
        totalCompressions: sql<number>`cast(count(*) as integer)`,
        totalSizeSaved: sql<number>`cast(coalesce(sum(${compressionLogs.originalSize} - ${compressionLogs.compressedSize}), 0) as integer)`,
        averageCompressionRatio: sql<number>`cast(coalesce(avg(${compressionLogs.compressionRatio}), 0) as integer)`,
        averageSizeReduced: sql<number>`cast(coalesce(avg(${compressionLogs.originalSize} - ${compressionLogs.compressedSize}), 0) as integer)`
      })
      .from(compressionLogs);

    return {
      totalCompressions: result.totalCompressions || 0,
      totalSizeSaved: result.totalSizeSaved || 0,
      averageCompressionRatio: result.averageCompressionRatio || 0,
      averageSizeReduced: result.averageSizeReduced || 0
    };
  }

  async getDailyCompressionStats(days = 7): Promise<{ date: string; count: number }[]> {
    // Get the date 'days' days ago
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - (days - 1));
    startDate.setHours(0, 0, 0, 0);

    // Query to get the daily count
    const results = await db
      .select({
        date: sql<string>`to_char(${compressionLogs.createdAt}, 'YYYY-MM-DD')`,
        count: sql<number>`cast(count(*) as integer)`
      })
      .from(compressionLogs)
      .where(gte(compressionLogs.createdAt, startDate))
      .groupBy(sql`to_char(${compressionLogs.createdAt}, 'YYYY-MM-DD')`)
      .orderBy(sql`to_char(${compressionLogs.createdAt}, 'YYYY-MM-DD')`);

    // Create a map of date to count from the results
    const dateCountMap = new Map();
    results.forEach(result => {
      dateCountMap.set(result.date, result.count);
    });

    // Generate all dates in the range with zero counts for missing dates
    const stats = [];
    for (let i = 0; i < days; i++) {
      const date = new Date(startDate);
      date.setDate(date.getDate() + i);
      const dateString = getLocalISOString(date).split('T')[0];
      stats.push({
        date: dateString,
        count: dateCountMap.get(dateString) || 0
      });
    }

    return stats;
  }
}

// Using the database implementation
export const storage = new DatabaseStorage();
