import mongoose, { Schema, Document } from 'mongoose';
import { z } from 'zod';

// For MongoDB, comment this out since we're using PostgreSQL in this implementation
// We'll keep the model definitions for reference
/*
mongoose.connect('mongodb://localhost:27017/imagecompress')
  .then(() => console.log('MongoDB connected'))
  .catch(err => {
    console.error('MongoDB connection error:', err);
    console.warn('Continuing without MongoDB. Some features may not work properly.');
  });
*/

// User Schema
export interface IUser extends Document {
  id: number;
  username: string;
  password: string;
  email: string;
  createdAt: Date;
}

const UserSchema = new Schema<IUser>({
  id: { type: Number, required: true, unique: true },
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  email: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

// Compression Log Schema
export interface ICompressionLog extends Document {
  id: number;
  userId: number | null;
  filename: string;
  originalSize: number;
  compressedSize: number;
  compressionRatio: number;
  format: string;
  width: number;
  height: number;
  quality: number;
  createdAt: Date;
  metadata: {
    originalWidth?: number;
    originalHeight?: number;
    resize?: boolean;
  } | null;
}

const CompressionLogSchema = new Schema<ICompressionLog>({
  id: { type: Number, required: true, unique: true },
  userId: { type: Number, required: false, default: null },
  filename: { type: String, required: true },
  originalSize: { type: Number, required: true },
  compressedSize: { type: Number, required: true },
  compressionRatio: { type: Number, required: true },
  format: { type: String, required: true },
  width: { type: Number, required: true, default: 0 },
  height: { type: Number, required: true, default: 0 },
  quality: { type: Number, required: true, default: 75 },
  createdAt: { type: Date, default: Date.now },
  metadata: {
    type: {
      originalWidth: { type: Number },
      originalHeight: { type: Number },
      resize: { type: Boolean }
    },
    required: false,
    default: null
  }
});

// Counter for auto-incrementing IDs
interface ICounter extends Document {
  _id: string;
  sequence_value: number;
}

const CounterSchema = new Schema<ICounter>({
  _id: { type: String, required: true },
  sequence_value: { type: Number, default: 0 }
});

const Counter = mongoose.model<ICounter>('Counter', CounterSchema);

// Pre-save hooks for auto-incrementing IDs
UserSchema.pre('save', async function(next) {
  if (this.isNew) {
    const counter = await Counter.findByIdAndUpdate(
      { _id: 'userId' },
      { $inc: { sequence_value: 1 } },
      { new: true, upsert: true }
    );
    this.id = counter.sequence_value;
  }
  next();
});

CompressionLogSchema.pre('save', async function(next) {
  if (this.isNew) {
    const counter = await Counter.findByIdAndUpdate(
      { _id: 'compressionLogId' },
      { $inc: { sequence_value: 1 } },
      { new: true, upsert: true }
    );
    this.id = counter.sequence_value;
  }
  next();
});

// Models
export const User = mongoose.model<IUser>('User', UserSchema);
export const CompressionLog = mongoose.model<ICompressionLog>('CompressionLog', CompressionLogSchema);

// Zod schemas for validation
export const insertUserSchema = z.object({
  username: z.string(),
  password: z.string(),
  email: z.string().email()
});

export const insertCompressionLogSchema = z.object({
  userId: z.number().optional().nullable(),
  filename: z.string(),
  originalSize: z.number(),
  compressedSize: z.number(),
  compressionRatio: z.number(),
  format: z.string(),
  width: z.number().optional().default(0),
  height: z.number().optional().default(0),
  quality: z.number().optional().default(75),
  metadata: z.object({
    originalWidth: z.number().optional(),
    originalHeight: z.number().optional(),
    resize: z.boolean().optional()
  }).optional().nullable()
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertCompressionLog = z.infer<typeof insertCompressionLogSchema>;