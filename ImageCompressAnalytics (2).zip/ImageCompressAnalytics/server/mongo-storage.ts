import { IStorage } from './storage';
import { 
  User, 
  CompressionLog, 
  type IUser, 
  type ICompressionLog, 
  type InsertUser, 
  type InsertCompressionLog 
} from './models/mongodb';
import { getLocalISOString } from '@shared/utils';

export class MongoDBStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<IUser | undefined> {
    const user = await User.findOne({ id });
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<IUser | undefined> {
    const user = await User.findOne({ username });
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<IUser> {
    const user = new User(insertUser);
    await user.save();
    return user;
  }

  // Compression log methods
  async createCompressionLog(insertLog: InsertCompressionLog): Promise<ICompressionLog> {
    const log = new CompressionLog({
      ...insertLog,
      width: insertLog.width || 0,
      height: insertLog.height || 0,
      quality: insertLog.quality || 75,
      metadata: insertLog.metadata || null
    });
    await log.save();
    return log;
  }

  async getCompressionLogs(limit = 10): Promise<ICompressionLog[]> {
    const logs = await CompressionLog.find()
      .sort({ createdAt: -1 })
      .limit(limit);
    return logs;
  }

  async getCompressionLogsByUserId(userId?: number, limit = 10): Promise<ICompressionLog[]> {
    if (userId) {
      return await CompressionLog.find({ userId })
        .sort({ createdAt: -1 })
        .limit(limit);
    }
    return this.getCompressionLogs(limit);
  }

  async getCompressionStats(): Promise<{
    totalCompressions: number;
    totalSizeSaved: number;
    averageCompressionRatio: number;
    averageSizeReduced: number;
  }> {
    const logs = await CompressionLog.find();
    const totalCompressions = logs.length;
    
    if (totalCompressions === 0) {
      return {
        totalCompressions: 0,
        totalSizeSaved: 0,
        averageCompressionRatio: 0,
        averageSizeReduced: 0,
      };
    }

    const totalSizeSaved = logs.reduce(
      (sum, log) => sum + (log.originalSize - log.compressedSize),
      0
    );
    
    const totalCompressionRatio = logs.reduce(
      (sum, log) => sum + log.compressionRatio,
      0
    );
    
    return {
      totalCompressions,
      totalSizeSaved,
      averageCompressionRatio: totalCompressionRatio / totalCompressions,
      averageSizeReduced: totalSizeSaved / totalCompressions,
    };
  }

  async getDailyCompressionStats(days = 7): Promise<{ date: string; count: number }[]> {
    // Calculate date range (last X days)
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Query logs in date range
    const logs = await CompressionLog.find({
      createdAt: { $gte: startDate, $lte: endDate }
    });

    // Create a map with zero counts for all days
    const dateMap = new Map<string, number>();
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = getLocalISOString(date).substring(0, 10);
      dateMap.set(dateStr, 0);
    }

    // Count logs by day
    logs.forEach(log => {
      const dateStr = getLocalISOString(new Date(log.createdAt)).substring(0, 10);
      const count = dateMap.get(dateStr) || 0;
      dateMap.set(dateStr, count + 1);
    });

    // Convert map to array and sort by date
    return Array.from(dateMap.entries())
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }
}

export const mongoStorage = new MongoDBStorage();