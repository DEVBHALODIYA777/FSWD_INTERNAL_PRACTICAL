import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage"; // Using PostgreSQL storage
import multer from "multer";
import sharp from "sharp";
import path from "path";
import fs from "fs";
import { insertCompressionLogSchema } from "@shared/schema"; // Using shared schema
import { z } from "zod";

// Set up multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (_req, file, cb) => {
    // Accept only image files
    const filetypes = /jpeg|jpg|png|gif|webp/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());

    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error("Error: Images Only!"));
  },
});

// Create a temporary directory for storing processed images
const tempDir = path.join(process.cwd(), "temp");
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir, { recursive: true });
}

export async function registerRoutes(app: Express): Promise<Server> {
  console.log("Starting to register routes...");
  // put application routes here
  // prefix all routes with /api

  // Get analytics data
  app.get("/api/analytics", async (_req: Request, res: Response) => {
    try {
      const stats = await storage.getCompressionStats();
      const dailyStats = await storage.getDailyCompressionStats(7);

      res.json({
        ...stats,
        dailyStats
      });
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics data" });
    }
  });

  // Get recent activity
  app.get("/api/activity", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const logs = await storage.getCompressionLogs(limit);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching activity logs:", error);
      res.status(500).json({ message: "Failed to fetch activity logs" });
    }
  });

  // Upload and compress image
  app.post("/api/compress", upload.single("image"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file uploaded" });
      }

      const compressionOptions = {
        quality: parseInt(req.body.quality || "75"),
        format: req.body.format || "jpeg",
        width: req.body.width ? parseInt(req.body.width) : undefined,
        height: req.body.height ? parseInt(req.body.height) : undefined,
        maintainAspectRatio: req.body.maintainAspectRatio === "true"
      };

      // Get image info before compression
      const originalImageInfo = await sharp(req.file.buffer).metadata();
      const originalSize = req.file.size;

      // Create Sharp instance
      let sharpInstance = sharp(req.file.buffer);

      // Resize if needed
      if (compressionOptions.width || compressionOptions.height) {
        sharpInstance = sharpInstance.resize({
          width: compressionOptions.width,
          height: compressionOptions.height,
          fit: compressionOptions.maintainAspectRatio ? "inside" : "fill"
        });
      }

      // Set format and quality
      switch (compressionOptions.format) {
        case "jpeg":
        case "jpg":
          sharpInstance = sharpInstance.jpeg({ quality: compressionOptions.quality });
          break;
        case "png":
          sharpInstance = sharpInstance.png({ quality: compressionOptions.quality });
          break;
        case "webp":
          sharpInstance = sharpInstance.webp({ quality: compressionOptions.quality });
          break;
        case "avif":
          sharpInstance = sharpInstance.avif({ quality: compressionOptions.quality });
          break;
        default:
          sharpInstance = sharpInstance.jpeg({ quality: compressionOptions.quality });
      }

      // Process the image
      const compressedBuffer = await sharpInstance.toBuffer();
      const compressedInfo = await sharp(compressedBuffer).metadata();
      const compressedSize = compressedBuffer.length;

      // Calculate compression ratio
      const compressionRatio = Math.round((1 - (compressedSize / originalSize)) * 100);

      // Generate a unique filename
      const timestamp = Date.now();
      const filename = `${path.parse(req.file.originalname).name}-compressed-${timestamp}.${compressionOptions.format}`;
      const outputPath = path.join(tempDir, filename);

      // Save the compressed image temporarily
      await fs.promises.writeFile(outputPath, compressedBuffer);

      // Log the compression
      const logData = {
        filename: req.file.originalname,
        originalSize,
        compressedSize,
        compressionRatio,
        format: compressionOptions.format,
        width: compressedInfo.width || 0,
        height: compressedInfo.height || 0,
        quality: compressionOptions.quality,
        metadata: {
          originalWidth: originalImageInfo.width,
          originalHeight: originalImageInfo.height,
          resize: !!(compressionOptions.width || compressionOptions.height)
        }
      };

      // Validate the log data
      const validatedData = insertCompressionLogSchema.parse(logData);
      const compressionLog = await storage.createCompressionLog(validatedData);

      res.json({
        success: true,
        original: {
          size: originalSize,
          width: originalImageInfo.width,
          height: originalImageInfo.height,
          filename: req.file.originalname
        },
        compressed: {
          size: compressedSize,
          width: compressedInfo.width,
          height: compressedInfo.height,
          filename,
          compressionRatio,
          downloadUrl: `/api/download/${filename}`
        },
        log: compressionLog
      });
    } catch (error) {
      console.error("Error compressing image:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid compression data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to compress image" });
    }
  });

  // Download compressed image
  app.get("/api/download/:filename", (req: Request, res: Response) => {
    try {
      const filename = req.params.filename;
      const filePath = path.join(tempDir, filename);
      
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "File not found" });
      }
      
      res.download(filePath);
    } catch (error) {
      console.error("Error downloading file:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });

  // Clear temporary files that are older than 1 hour
  setInterval(() => {
    try {
      const files = fs.readdirSync(tempDir);
      const now = Date.now();
      
      files.forEach(file => {
        const filePath = path.join(tempDir, file);
        const stats = fs.statSync(filePath);
        const fileAge = now - stats.mtimeMs;
        
        // Delete files older than 1 hour (3600000 ms)
        if (fileAge > 3600000) {
          fs.unlinkSync(filePath);
        }
      });
    } catch (error) {
      console.error("Error cleaning up temp directory:", error);
    }
  }, 3600000); // Run every hour

  const httpServer = createServer(app);

  return httpServer;
}
