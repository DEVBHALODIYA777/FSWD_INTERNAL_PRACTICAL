import express from "express";
import type { Express, Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { serveStatic, setupVite, log } from "./vite";
// For PostgreSQL only, no need to import MongoDB

const app = express();

async function main() {
  console.log("Starting application...");
  app.use(express.json());

  try {
    console.log("Registering routes...");
    // Only use Vite in development mode
    // Always create a server and bind to a port
    const server = await registerRoutes(app);
    const port = process.env.PORT || 5000;
    
    if (process.env.NODE_ENV !== "production") {
      console.log("Setting up Vite...");
      await setupVite(app, server);
      
      // Start listening on the port
      server.listen(port, '0.0.0.0', () => {
        console.log(`Server listening on port ${port}`);
      });
    } else {
      serveStatic(app);
      server.listen(port, '0.0.0.0', () => {
        log(`serving on port ${port}`);
      });
    }
    console.log("Server setup complete!");
  } catch (error) {
    console.error("Error setting up the server:", error);
    throw error;
  }

  // Error handling middleware
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});