import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const compressionLogs = pgTable("compression_logs", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  originalSize: integer("original_size").notNull(), // in bytes
  compressedSize: integer("compressed_size").notNull(), // in bytes
  compressionRatio: integer("compression_ratio").notNull(), // percentage
  format: text("format").notNull(), // jpg, png, webp, etc.
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  quality: integer("quality").notNull(), // 1-100
  createdAt: timestamp("created_at").defaultNow().notNull(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  metadata: json("metadata").$type<{
    originalWidth?: number;
    originalHeight?: number;
    resize?: boolean;
  }>(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCompressionLogSchema = createInsertSchema(compressionLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type CompressionLog = typeof compressionLogs.$inferSelect;
export type InsertCompressionLog = z.infer<typeof insertCompressionLogSchema>;
