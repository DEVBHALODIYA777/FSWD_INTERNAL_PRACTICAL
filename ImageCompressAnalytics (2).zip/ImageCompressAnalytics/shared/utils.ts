/**
 * Get an ISO string that preserves the local timezone information
 * @param date Date object to convert
 * @returns ISO string with local timezone
 */
export function getLocalISOString(date: Date): string {
  const offset = date.getTimezoneOffset();
  const localDate = new Date(date.getTime() - offset * 60 * 1000);
  return localDate.toISOString();
}