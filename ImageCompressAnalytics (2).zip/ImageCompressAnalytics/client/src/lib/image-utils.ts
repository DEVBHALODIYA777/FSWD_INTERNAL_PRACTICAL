/**
 * Format file size in bytes to a human-readable format
 * @param bytes Size in bytes
 * @returns Formatted size string (e.g. "1.5 MB")
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

/**
 * Calculate compression ratio between original and compressed size
 * @param originalSize Original size in bytes
 * @param compressedSize Compressed size in bytes
 * @returns Compression ratio as percentage
 */
export function calculateCompressionRatio(originalSize: number, compressedSize: number): number {
  if (originalSize === 0) return 0;
  return Math.round((1 - (compressedSize / originalSize)) * 100);
}

/**
 * Check if file is an accepted image type
 * @param file File to check
 * @returns Boolean indicating if file is an accepted image
 */
export function isAcceptedImageType(file: File): boolean {
  const acceptedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
  return acceptedTypes.includes(file.type);
}

/**
 * Check if file size is within limit
 * @param file File to check
 * @param maxSizeBytes Maximum size in bytes
 * @returns Boolean indicating if file is within size limit
 */
export function isWithinSizeLimit(file: File, maxSizeBytes: number = 10 * 1024 * 1024): boolean {
  return file.size <= maxSizeBytes;
}
