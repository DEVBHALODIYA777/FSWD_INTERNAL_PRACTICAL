import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';

interface CompressionOptionsProps {
  imageFile: File | null;
  onCompressResult: (result: any) => void;
  hasImage: boolean;
}

const formatOptions = [
  { value: 'jpeg', label: 'JPG' },
  { value: 'png', label: 'PNG' },
  { value: 'webp', label: 'WEBP' },
  { value: 'avif', label: 'AVIF' }
];

export default function CompressionOptions({ imageFile, onCompressResult, hasImage }: CompressionOptionsProps) {
  const [qualityLevel, setQualityLevel] = useState(75);
  const [format, setFormat] = useState('jpeg');
  const [maintainAspectRatio, setMaintainAspectRatio] = useState(true);
  const [dimensions, setDimensions] = useState({ width: '', height: '' });
  const [isCompressing, setIsCompressing] = useState(false);
  const [compressedImage, setCompressedImage] = useState<any>(null);
  const { toast } = useToast();

  if (!hasImage) {
    return null;
  }

  const handleQualityChange = (value: number[]) => {
    setQualityLevel(value[0]);
  };

  const handleFormatSelect = (selectedFormat: string) => {
    setFormat(selectedFormat);
  };

  const handleWidthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDimensions(prev => ({ ...prev, width: e.target.value }));
  };

  const handleHeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDimensions(prev => ({ ...prev, height: e.target.value }));
  };

  const handleCompressImage = async () => {
    if (!imageFile) {
      toast({
        title: 'No image selected',
        description: 'Please upload an image first.',
        variant: 'destructive'
      });
      return;
    }

    try {
      setIsCompressing(true);
      
      const formData = new FormData();
      formData.append('image', imageFile);
      formData.append('quality', qualityLevel.toString());
      formData.append('format', format);
      formData.append('maintainAspectRatio', maintainAspectRatio.toString());
      
      if (dimensions.width) {
        formData.append('width', dimensions.width);
      }
      
      if (dimensions.height) {
        formData.append('height', dimensions.height);
      }
      
      const response = await fetch('/api/compress', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Failed to compress image');
      }
      
      const result = await response.json();
      setCompressedImage(result);
      onCompressResult(result);
      
      // Invalidate analytics queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/analytics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activity'] });
      
      toast({
        title: 'Image compressed successfully',
        description: `Reduced by ${result.compressed.compressionRatio}%`,
        variant: 'default'
      });
    } catch (error) {
      console.error('Compression error:', error);
      toast({
        title: 'Compression failed',
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: 'destructive'
      });
    } finally {
      setIsCompressing(false);
    }
  };

  const handleDownload = () => {
    if (compressedImage && compressedImage.compressed) {
      window.location.href = compressedImage.compressed.downloadUrl;
    } else {
      toast({
        title: 'No compressed image',
        description: 'Please compress the image first.',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-medium leading-6 text-gray-900">Compression Options</h3>
      </div>
      <div className="p-6">
        <div className="space-y-6">
          {/* Quality Control */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <Label htmlFor="quality" className="block text-sm font-medium text-gray-700">Quality</Label>
              <span className="text-sm text-gray-500">{qualityLevel}%</span>
            </div>
            <Slider
              id="quality"
              defaultValue={[75]}
              min={1}
              max={100}
              step={1}
              value={[qualityLevel]}
              onValueChange={handleQualityChange}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Low Quality (Smaller Size)</span>
              <span>High Quality (Larger Size)</span>
            </div>
          </div>
          
          {/* Output Format */}
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">Output Format</Label>
            <div className="grid grid-cols-4 gap-3">
              {formatOptions.map((option) => (
                <Button
                  key={option.value}
                  variant={format === option.value ? 'default' : 'outline'}
                  onClick={() => handleFormatSelect(option.value)}
                  className="px-3 text-sm"
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Resize Options */}
          <div>
            <div className="flex justify-between">
              <Label className="block text-sm font-medium text-gray-700 mb-2">Resize Image</Label>
              <div className="flex items-center space-x-2">
                <Label htmlFor="aspect-ratio" className="text-sm text-gray-500">Maintain aspect ratio</Label>
                <Switch
                  id="aspect-ratio"
                  checked={maintainAspectRatio}
                  onCheckedChange={setMaintainAspectRatio}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="width" className="block text-xs font-medium text-gray-700 mb-1">Width</Label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <Input 
                    type="number" 
                    id="width" 
                    placeholder="Width in pixels" 
                    value={dimensions.width}
                    onChange={handleWidthChange}
                    className="pr-8"
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                    <span className="text-gray-500 sm:text-sm">px</span>
                  </div>
                </div>
              </div>
              <div>
                <Label htmlFor="height" className="block text-xs font-medium text-gray-700 mb-1">Height</Label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <Input 
                    type="number" 
                    id="height" 
                    placeholder="Height in pixels" 
                    value={dimensions.height}
                    onChange={handleHeightChange}
                    className="pr-8"
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                    <span className="text-gray-500 sm:text-sm">px</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 mt-6">
            <Button 
              className="flex-1" 
              onClick={handleCompressImage}
              disabled={isCompressing}
            >
              {isCompressing ? 'Compressing...' : 'Compress Image'}
            </Button>
            <Button 
              variant="outline" 
              className="flex-1" 
              onClick={handleDownload}
              disabled={!compressedImage}
            >
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
