import { useState, useRef, useEffect } from 'react';
import { formatFileSize } from '@/lib/image-utils';
import { Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ImagePreviewProps {
  originalUrl: string | null;
  compressedUrl: string | null;
  originalInfo: {
    size: number;
    width: number;
    height: number;
    filename: string;
  } | null;
  compressedInfo: {
    size: number;
    width: number;
    height: number;
    filename: string;
    compressionRatio: number;
  } | null;
}

export default function ImagePreview({ 
  originalUrl, 
  compressedUrl, 
  originalInfo, 
  compressedInfo 
}: ImagePreviewProps) {
  const [sliderPosition, setSliderPosition] = useState(50);
  const sliderRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    if (!compressedUrl) {
      setSliderPosition(50);
    }
  }, [compressedUrl]);

  const handleSliderMove = (clientX: number) => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const x = clientX - rect.left;
      const position = Math.min(Math.max((x / rect.width) * 100, 0), 100);
      setSliderPosition(position);
    }
  };

  const handleMouseDown = () => {
    setIsDragging(true);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      handleSliderMove(e.clientX);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    handleSliderMove(e.touches[0].clientX);
  };

  const handleContainerClick = (e: React.MouseEvent) => {
    handleSliderMove(e.clientX);
  };

  const handleDownload = () => {
    if (compressedUrl) {
      window.location.href = compressedUrl;
    }
  };

  if (!originalUrl) {
    return null;
  }

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="px-4 sm:px-6 py-4 sm:py-5 border-b border-gray-200 flex justify-between items-center">
        <h3 className="text-base sm:text-lg font-medium leading-6 text-gray-900">
          Image Preview
        </h3>
        {compressedUrl && (
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleDownload}
            className="flex items-center text-xs sm:text-sm"
          >
            <Download className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            Download
          </Button>
        )}
      </div>
      <div className="p-3 sm:p-6">
        {/* Comparison Slider Instructions */}
        {compressedUrl && (
          <p className="text-xs text-center text-gray-500 mb-2">
            Drag slider to compare original and compressed images
          </p>
        )}
        
        {/* Image Preview Container */}
        <div 
          ref={containerRef}
          className="image-comparison-container aspect-w-16 aspect-h-9 bg-gray-100 rounded-lg overflow-hidden relative" 
          style={{ height: 'auto', minHeight: '200px', maxHeight: '300px' }}
          onClick={handleContainerClick}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onTouchEnd={handleMouseUp}
        >
          <div className="image-comparison-slider h-full">
            {/* Original image */}
            <div 
              className="original h-full w-full bg-center bg-contain bg-no-repeat" 
              style={{ backgroundImage: `url(${originalUrl})` }}
            />
            
            {/* Compressed image */}
            {compressedUrl ? (
              <div 
                className="compressed h-full bg-center bg-contain bg-no-repeat" 
                style={{ 
                  backgroundImage: `url(${compressedUrl})`,
                  width: `${sliderPosition}%`
                }}
              />
            ) : null}
            
            {/* Slider handle */}
            {compressedUrl ? (
              <div 
                ref={sliderRef}
                className="slider-handle"
                style={{ left: `${sliderPosition}%` }}
                onMouseDown={handleMouseDown}
                onTouchStart={handleMouseDown}
                onTouchMove={handleTouchMove}
              />
            ) : null}
          </div>
          
          {/* Labels */}
          <div className="absolute top-2 sm:top-4 left-2 sm:left-4 bg-gray-900 bg-opacity-75 text-white text-xs px-2 py-1 rounded">
            Original
          </div>
          {compressedUrl ? (
            <div className="absolute top-2 sm:top-4 right-2 sm:right-4 bg-primary bg-opacity-75 text-white text-xs px-2 py-1 rounded">
              Compressed
            </div>
          ) : null}
        </div>
        
        {/* Image info */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm">
          <div className="p-3 rounded-lg bg-gray-50">
            <p className="font-medium text-gray-700">Original</p>
            {originalInfo ? (
              <>
                <p className="text-gray-500 truncate" title={originalInfo.filename}>
                  {originalInfo.filename}
                </p>
                <p className="text-gray-500">
                  {formatFileSize(originalInfo.size)} · 
                  {originalInfo.width}×{originalInfo.height}
                </p>
              </>
            ) : (
              <p className="text-gray-500">Loading image information...</p>
            )}
          </div>
          {compressedInfo ? (
            <div className="p-3 rounded-lg bg-green-50">
              <p className="font-medium text-gray-700">Compressed</p>
              <div className="text-gray-500 truncate" title={compressedInfo.filename}>
                {compressedInfo.filename}
              </div>
              <p className="text-green-600 font-medium">
                {formatFileSize(compressedInfo.size)} · 
                {compressedInfo.width}×{compressedInfo.height}
              </p>
              <div className="mt-1 bg-green-100 text-green-800 text-xs font-medium px-2 py-0.5 rounded-full inline-flex">
                {compressedInfo.compressionRatio}% reduced
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
