import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Image } from "lucide-react";
import { formatFileSize } from '@/lib/image-utils';
import { formatDistance } from 'date-fns';

interface CompressionLog {
  id: number;
  filename: string;
  originalSize: number;
  compressedSize: number;
  compressionRatio: number;
  format: string;
  createdAt: string;
}

export default function ActivityLog({ logs }: { logs: CompressionLog[] }) {
  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    return formatDistance(date, new Date(), { addSuffix: true });
  };
  
  return (
    <Card>
      <CardHeader className="px-6 py-5 border-b border-gray-200">
        <CardTitle className="text-lg font-medium text-gray-900">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="px-6 py-4">
        <div className="flow-root">
          {logs.length > 0 ? (
            <ul className="-my-5 divide-y divide-gray-200">
              {logs.map((log) => (
                <li key={log.id} className="py-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      <div className="h-10 w-10 rounded bg-gray-200 flex items-center justify-center text-gray-500">
                        <Image className="h-6 w-6" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {log.filename}
                      </p>
                      <p className="text-sm text-gray-500">
                        Compressed from {formatFileSize(log.originalSize)} to {formatFileSize(log.compressedSize)} ({log.compressionRatio}% reduction)
                      </p>
                    </div>
                    <div>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                        {formatTimeAgo(log.createdAt)}
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="py-6 text-center">
              <p className="text-sm text-gray-500">No compression activity yet.</p>
              <p className="text-sm text-gray-500 mt-1">Upload and compress an image to get started.</p>
            </div>
          )}
        </div>
        
        {logs.length > 0 && (
          <div className="mt-5">
            <a href="#" className="text-sm font-medium text-primary hover:text-blue-600">
              View all activity
              <span aria-hidden="true"> &rarr;</span>
            </a>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
