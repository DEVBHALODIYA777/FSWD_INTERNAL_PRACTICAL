import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { formatFileSize } from '@/lib/image-utils';

interface AnalyticsData {
  totalCompressions: number;
  totalSizeSaved: number;
  averageCompressionRatio: number;
  averageSizeReduced: number;
  dailyStats: { date: string; count: number }[];
}

export default function AnalyticsOverview({ data }: { data: AnalyticsData }) {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const chartData = data.dailyStats.map(stat => ({
    name: formatDate(stat.date),
    compressions: stat.count
  }));

  return (
    <Card>
      <CardHeader className="px-6 py-5 border-b border-gray-200">
        <CardTitle className="text-lg font-medium text-gray-900">Analytics Overview</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-2 gap-6 mb-6">
          {/* Total Compressions */}
          <div className="bg-gray-50 rounded-lg p-4">
            <dt className="text-sm font-medium text-gray-500 truncate">Total Compressions</dt>
            <dd className="mt-1 text-3xl font-semibold text-gray-900">{data.totalCompressions}</dd>
          </div>
          
          {/* Total Size Saved */}
          <div className="bg-gray-50 rounded-lg p-4">
            <dt className="text-sm font-medium text-gray-500 truncate">Total Size Saved</dt>
            <dd className="mt-1 text-3xl font-semibold text-green-600">
              {formatFileSize(data.totalSizeSaved)}
            </dd>
          </div>
        </div>
        
        {/* Chart */}
        <div className="bg-gray-50 rounded-lg p-4 mb-6 h-56">
          <p className="text-sm text-gray-500 text-center mb-2">Compression Activity (Last 7 Days)</p>
          <ResponsiveContainer width="100%" height="85%">
            <BarChart
              data={chartData}
              margin={{
                top: 5,
                right: 5,
                left: 0,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" axisLine={false} tickLine={false} />
              <YAxis axisLine={false} tickLine={false} />
              <Tooltip />
              <Bar dataKey="compressions" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        {/* Average Metrics */}
        <div className="grid grid-cols-2 gap-6">
          <div className="bg-gray-50 rounded-lg p-4">
            <dt className="text-sm font-medium text-gray-500 truncate">Avg. Compression</dt>
            <dd className="mt-1 text-2xl font-semibold text-gray-900">{data.averageCompressionRatio}%</dd>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <dt className="text-sm font-medium text-gray-500 truncate">Avg. Size Reduced</dt>
            <dd className="mt-1 text-2xl font-semibold text-gray-900">
              {formatFileSize(data.averageSizeReduced)}
            </dd>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
