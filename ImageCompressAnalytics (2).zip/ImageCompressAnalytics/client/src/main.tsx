import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

document.title = "ImageSlim - Image Compression & Analytics";

createRoot(document.getElementById("root")!).render(<App />);
