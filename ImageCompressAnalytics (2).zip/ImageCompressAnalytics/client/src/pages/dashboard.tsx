import { useQuery } from "@tanstack/react-query";
import ImageUploader from "@/components/image-uploader";
import ImagePreview from "@/components/image-preview";
import CompressionOptions from "@/components/compression-options";
import AnalyticsOverview from "@/components/analytics-overview";
import ActivityLog from "@/components/activity-log";
import { useState } from "react";

// Define types to match the component interfaces
interface AnalyticsData {
  totalCompressions: number;
  totalSizeSaved: number;
  averageCompressionRatio: number;
  averageSizeReduced: number;
  dailyStats: { date: string; count: number }[];
}

interface CompressionLog {
  id: number;
  filename: string;
  originalSize: number;
  compressedSize: number;
  compressionRatio: number;
  format: string;
  createdAt: string;
}

export default function Dashboard() {
  const [currentImage, setCurrentImage] = useState<{
    file: File | null;
    preview: string | null;
    compressed: {
      downloadUrl: string;
      size: number;
      width: number;
      height: number;
      filename: string;
      compressionRatio: number;
      previewUrl: string;
    } | null;
    original: {
      size: number;
      width: number;
      height: number;
      filename: string;
    } | null;
  }>({
    file: null,
    preview: null,
    compressed: null,
    original: null
  });

  // Get analytics
  const { data: analyticsData } = useQuery<AnalyticsData>({
    queryKey: ['/api/analytics'],
    staleTime: 60000, // 1 minute
  });

  // Get activity logs
  const { data: activityLogs } = useQuery<CompressionLog[]>({
    queryKey: ['/api/activity'],
    staleTime: 60000, // 1 minute
  });

  const handleImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      setCurrentImage({
        file,
        preview: reader.result as string,
        compressed: null,
        original: null
      });
    };
    reader.readAsDataURL(file);
  };

  const handleCompressResult = (result: any) => {
    if (result && currentImage.preview) {
      // Create a blob URL for the compressed image
      setCurrentImage({
        ...currentImage,
        compressed: {
          ...result.compressed,
          previewUrl: result.compressed.downloadUrl
        },
        original: result.original
      });
    }
  };

  // Default values for analytics if data isn't loaded yet
  const defaultAnalytics: AnalyticsData = {
    totalCompressions: 0,
    totalSizeSaved: 0,
    averageCompressionRatio: 0,
    averageSizeReduced: 0,
    dailyStats: []
  };

  return (
    <main className="flex-1 w-full mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 sm:gap-6">
        {/* Left Column - Upload & Compress */}
        <div className="xl:col-span-7 space-y-4 sm:space-y-6">
          <div className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-lg p-4 sm:p-6 mb-2 sm:mb-4">
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Image Compression</h1>
            <p className="mt-2 text-gray-600">Upload, compress, and optimize your images instantly.</p>
          </div>
          
          <ImageUploader 
            onUpload={handleImageUpload} 
            hasImage={!!currentImage.preview}
          />

          {currentImage.preview && (
            <>
              <ImagePreview 
                originalUrl={currentImage.preview}
                compressedUrl={currentImage.compressed?.previewUrl || null}
                originalInfo={currentImage.original}
                compressedInfo={currentImage.compressed}
              />
              <CompressionOptions 
                imageFile={currentImage.file}
                onCompressResult={handleCompressResult}
                hasImage={!!currentImage.preview}
              />
            </>
          )}
        </div>

        {/* Right Column - Analytics & Logs */}
        <div className="xl:col-span-5 space-y-4 sm:space-y-6 mt-4 xl:mt-0">
          <AnalyticsOverview 
            data={analyticsData || defaultAnalytics} 
          />
          <ActivityLog logs={activityLogs || []} />
        </div>
      </div>
    </main>
  );
}
